package org.tasks.preferences

import com.todoroo.astrid.core.SortHelper

class DefaultQueryPreferences : QueryPreferences {
    override var sortMode = SortHelper.SORT_DUE
    override var groupMode = SortHelper.SORT_DUE
    override var completedMode = SortHelper.SORT_AUTO
    override var subtaskMode = SortHelper.SORT_MANUAL
    override var isManualSort = false
    override var isAstridSort = false
    override var sortAscending = true
    override var groupAscending = true
    override var completedAscending = false
    override var subtaskAscending = false
    override var showHidden = false
    override var showCompleted = true
    override var showCompletedSubtasks = true
    override val alwaysDisplayFullDate = false
    override var completedTasksAtBottom = true
}
