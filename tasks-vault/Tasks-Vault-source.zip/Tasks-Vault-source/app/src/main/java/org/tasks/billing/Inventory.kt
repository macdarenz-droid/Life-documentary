package org.tasks.billing

import android.content.Context
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.tasks.BuildConfig
import org.tasks.LocalBroadcastManager
import org.tasks.R
import org.tasks.TasksApplication.Companion.IS_GENERIC
import org.tasks.data.dao.CaldavDao
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_CALDAV
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_TASKS
import org.tasks.data.isTasksSubscription
import org.tasks.extensions.Context.openUri
import org.tasks.injection.ApplicationScope
import org.tasks.preferences.Preferences
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Inventory @Inject constructor(
        @ApplicationScope scope: CoroutineScope,
        private val preferences: Preferences,
        private val signatureVerifier: SignatureVerifier,
        private val localBroadcastManager: LocalBroadcastManager,
        private val caldavDao: CaldavDao
) : PurchaseState {
    val purchases: MutableMap<String, Purchase> = HashMap()
    val subscription = MutableLiveData<Purchase?>()

    override var hasTasksAccount = false
        private set

    fun clear() {
        Timber.d("clear()")
        purchases.clear()
        subscription.value = null
    }

    fun add(items: Iterable<Purchase>) {
        verifyAndAdd(items)
        preferences.setPurchases(purchases.values)
        localBroadcastManager.broadcastPurchasesUpdated()
    }

    private fun verifyAndAdd(items: Iterable<Purchase>) {
        for (purchase in items) {
            if (signatureVerifier.verifySignature(purchase)) {
                Timber.d("add(%s)", purchase)
                purchases[purchase.sku] = purchase
            }
        }
        hasPro = purchases.values.any { it.isProSubscription } || purchases.containsKey(SKU_VIP)
        updateSubscription()
    }

    override val hasTasksSubscription: Boolean
        get() = subscription.value?.isTasksSubscription == true || hasTasksAccount

    val begForMoney: Boolean
        get() = if (IS_GENERIC) !hasTasksAccount else !hasPro

    override fun purchasedThemes() = hasPro || purchases.containsKey(SKU_THEMES)

    @Suppress("SimplifyBooleanWithConstants")
    override var hasPro = false
        get() {
            @Suppress("KotlinConstantConditions")
            return IS_GENERIC
                    || (BuildConfig.DEBUG && preferences.getBoolean(R.string.p_debug_pro, false))
                    || hasTasksAccount
                    || field
        }
        private set

    suspend fun updateTasksAccount() {
        hasTasksAccount = caldavDao.getAccounts(TYPE_TASKS, TYPE_CALDAV).any {
            it.isTasksSubscription()
        }
    }

    fun getPurchase(sku: String) = purchases[sku]

    private fun updateSubscription() {
        subscription.value = purchases
                .values
                .filter { it.isProSubscription }
                .sortedWith { l, r ->
                    r.isMonthly.compareTo(l.isMonthly)
                            .takeIf { it != 0 }?.let { return@sortedWith it }
                    l.isCanceled.compareTo(r.isCanceled)
                            .takeIf { it != 0 }?.let { return@sortedWith it }
                    r.subscriptionPrice!!.compareTo(l.subscriptionPrice!!)
                }
                .firstOrNull()
    }

    fun unsubscribe(context: Context): Boolean {
        subscription.value?.let {
            context.openUri(R.string.manage_subscription_url, it.sku)
        }
        return false
    }

    companion object {
        private const val SKU_VIP = "vip"
        const val SKU_THEMES = "themes"
    }

    init {
        scope.launch(Dispatchers.Main.immediate) {
            verifyAndAdd(preferences.purchases)
        }
    }
}
