package org.tasks.preferences

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceFragmentCompat
import com.todoroo.astrid.gtasks.auth.GtasksLoginActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import org.tasks.LocalBroadcastManager
import org.tasks.R
import org.tasks.resources.getString
import tasks.kmp.generated.resources.Res
import tasks.kmp.generated.resources.tasks_org
import org.tasks.auth.SignInActivity
import org.tasks.extensions.Context.toast
import org.tasks.preferences.fragments.MainSettingsComposeFragment
import org.tasks.preferences.fragments.MainSettingsComposeFragment.Companion.REQUEST_GOOGLE_TASKS
import org.tasks.preferences.fragments.MainSettingsComposeFragment.Companion.REQUEST_TASKS_ORG
import org.tasks.preferences.fragments.TasksAccount
import javax.inject.Inject

@AndroidEntryPoint
class MainPreferences : BasePreferences() {

    @Inject lateinit var localBroadcastManager: LocalBroadcastManager

    private val viewModel: PreferencesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        firebase.logEvent(R.string.event_screen_settings)
    }

    override fun getRootTitle() = R.string.TLA_menu_settings

    override fun getRootPreference() = MainSettingsComposeFragment()

    override fun onResume() {
        super.onResume()

        localBroadcastManager.registerPreferenceReceiver(refreshReceiver)

        viewModel.updateBackups()
    }

    override fun onPause() {
        super.onPause()

        localBroadcastManager.unregisterReceiver(refreshReceiver)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_GOOGLE_TASKS -> if (resultCode != Activity.RESULT_OK) {
                data?.getStringExtra(GtasksLoginActivity.EXTRA_ERROR)?.let { toast(it) }
            }
            REQUEST_TASKS_ORG -> if (resultCode == Activity.RESULT_OK) {
                lifecycleScope.launch {
                    val account = viewModel.tasksAccount() ?: return@launch
                    val fragment = supportFragmentManager.findFragmentById(R.id.settings)
                    if (fragment !is TasksAccount) {
                        startPreference(
                                TasksAccount.newTasksAccountPreference(account),
                                getString(Res.string.tasks_org)
                        )
                    }
                }
            } else {
                data?.getStringExtra(SignInActivity.EXTRA_ERROR)?.let { toast(it) }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.updateBackups()
        }
    }
}