package org.tasks.compose

import org.tasks.resources.getString
import org.tasks.themes.TasksIcons
import org.tasks.compose.components.SymbolIcon
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import tasks.kmp.generated.resources.sign_in
import tasks.kmp.generated.resources.sign_in_subtitle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.PreviewFontScale
import androidx.compose.ui.tooling.preview.PreviewLightDark
import androidx.compose.ui.tooling.preview.PreviewScreenSizes
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlinx.coroutines.runBlocking
import org.jetbrains.compose.resources.stringResource as composeStringResource
import org.tasks.R
import org.tasks.billing.Sku
import org.tasks.billing.SubscriptionSkus
import org.tasks.compose.Constants.HALF_KEYLINE
import org.tasks.compose.Constants.KEYLINE_FIRST
import org.tasks.compose.PurchaseText.SubscriptionScreen
import org.tasks.compose.settings.SettingsCardRadius
import org.tasks.extensions.Context.openUri
import org.tasks.themes.TasksTheme
import tasks.kmp.generated.resources.Res
import tasks.kmp.generated.resources.supporter
import tasks.kmp.generated.resources.tasks_org_account
import tasks.kmp.generated.resources.upgrade_subscription_banner
import tasks.kmp.generated.resources.url_sponsor

object PurchaseText {
    private const val POPPER = "\uD83C\uDF89"

    enum class IconStyle { TINT, ORIGINAL }

    data class CarouselItem(
        val title: Int,
        val icon: Int,
        val description: Int,
        val iconStyle: IconStyle = IconStyle.TINT,
    )

    private val nameYourPriceFeatureList = listOf(
        CarouselItem(
            title = R.string.upgrade_desktop_app,
            icon = R.drawable.ic_outline_computer_24px,
            description = R.string.upgrade_desktop_app_description,
        ),
        CarouselItem(
            R.string.upgrade_more_customization,
            R.drawable.ic_outline_palette_24px,
            R.string.upgrade_more_customization_description
        ),
        CarouselItem(
            R.string.open_source,
            R.drawable.ic_outline_favorite_border_24px,
            R.string.upgrade_open_source_description
        ),
        CarouselItem(
            R.string.davx5,
            R.drawable.ic_davx5_icon_green_bg,
            R.string.davx5_selection_description,
            iconStyle = IconStyle.ORIGINAL
        ),
        CarouselItem(
            R.string.caldav,
            R.drawable.ic_webdav_logo,
            R.string.caldav_selection_description
        ),
        CarouselItem(
            R.string.etesync,
            R.drawable.ic_etesync,
            R.string.etesync_selection_description,
            iconStyle = IconStyle.ORIGINAL
        ),
        CarouselItem(
            R.string.decsync,
            R.drawable.ic_decsync,
            R.string.decsync_selection_description,
            iconStyle = IconStyle.ORIGINAL
        ),
    )

    private val tasksOrgFeatureList = listOf(
        CarouselItem(
            R.string.tasks_org_account,
            R.drawable.ic_round_icon,
            R.string.upgrade_tasks_org_account_description,
            iconStyle = IconStyle.ORIGINAL
        ),
        CarouselItem(
            title = R.string.upgrade_desktop_app,
            icon = R.drawable.ic_outline_computer_24px,
            description = R.string.upgrade_desktop_app_description,
        ),
        CarouselItem(
            title = R.string.upgrade_friends_and_family,
            icon = R.drawable.outline_groups_24,
            description = R.string.upgrade_friends_and_family_description,
        ),
        CarouselItem(
            R.string.email_to_task,
            R.drawable.ic_outline_email_24px,
            R.string.upgrade_email_to_task_description
        ),
        CarouselItem(
            R.string.upgrade_more_customization,
            R.drawable.ic_outline_palette_24px,
            R.string.upgrade_more_customization_description
        ),
        CarouselItem(
            R.string.open_source,
            R.drawable.ic_outline_favorite_border_24px,
            R.string.upgrade_open_source_description
        ),
        CarouselItem(
            R.string.advanced_tools,
            R.drawable.ic_outline_build_24px,
            R.string.advanced_tools_description
        ),
    )

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun SubscriptionScreen(
        nameYourPrice: Boolean,
        sliderPosition: Float,
        feature: Int = 0,
        github: Boolean = false,
        showMoreOptions: Boolean = true,
        existingSubscriber: Boolean = false,
        hasTasksAccount: Boolean = false,
        onSignIn: () -> Unit = {},
        snackbarHostState: SnackbarHostState = remember { SnackbarHostState() },
        setPrice: (Float) -> Unit,
        setNameYourPrice: (Boolean) -> Unit,
        subscribe: (Int, Boolean) -> Unit,
        skus: List<Sku>,
        onBack: () -> Unit,
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = if (nameYourPrice) {
                                composeStringResource(Res.string.supporter)
                            } else {
                                composeStringResource(Res.string.tasks_org_account)
                            },
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            SymbolIcon(
                                name = TasksIcons.ARROW_BACK,
                                contentDescription = null
                            )
                        }
                    },
                    actions = {
                        if (existingSubscriber && !github && !hasTasksAccount) {
                            var expanded by remember { mutableStateOf(false) }
                            IconButton(onClick = { expanded = true }) {
                                SymbolIcon(
                                    name = TasksIcons.MORE_VERT,
                                    contentDescription = null,
                                )
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                            ) {
                                DropdownMenuItem(
                                    text = { Text(composeStringResource(Res.string.sign_in)) },
                                    onClick = {
                                        expanded = false
                                        onSignIn()
                                    },
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .background(color = MaterialTheme.colorScheme.surface),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (existingSubscriber && !nameYourPrice && !showMoreOptions && !github) {
                    ElevatedCard(
                        modifier = Modifier
                            .widthIn(max = 480.dp)
                            .fillMaxWidth()
                            .padding(KEYLINE_FIRST, KEYLINE_FIRST, KEYLINE_FIRST, 0.dp),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                        ),
                    ) {
                        Text(
                            text = composeStringResource(Res.string.upgrade_subscription_banner),
                            modifier = Modifier.padding(KEYLINE_FIRST),
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
                Card(
                    modifier = Modifier
                        .widthIn(max = 480.dp)
                        .fillMaxWidth()
                        .padding(KEYLINE_FIRST, KEYLINE_FIRST, KEYLINE_FIRST, 0.dp),
                    shape = RoundedCornerShape(SettingsCardRadius),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    ),
                ) {
                    GreetingText(R.string.upgrade_blurb_1)
                    GreetingText(R.string.upgrade_blurb_2)
                    Spacer(Modifier.height(KEYLINE_FIRST))
                }
                Spacer(Modifier.height(KEYLINE_FIRST))
                val scrollState = rememberScrollState()
                val items = remember(nameYourPrice, feature) {
                    if (nameYourPrice) {
                        val reordered = nameYourPriceFeatureList.toMutableList()
                        if (feature != 0) {
                            val index = reordered.indexOfFirst { it.title == feature }
                            if (index > 0) {
                                reordered.add(0, reordered.removeAt(index))
                            }
                        }
                        reordered
                    } else {
                        tasksOrgFeatureList
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .height(IntrinsicSize.Max)
                        .padding(horizontal = KEYLINE_FIRST),
                    horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                ) {
                    items.forEach { item ->
                        PagerItem(feature = item)
                    }
                }
                if (github) {
                    Spacer(Modifier.height(KEYLINE_FIRST))
                    SponsorButton()
                    Spacer(Modifier.height(KEYLINE_FIRST))
                    Button(
                        onClick = onSignIn,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    ) {
                        Text(
                            text = composeStringResource(Res.string.sign_in),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    GooglePlayButtons(
                        nameYourPrice = nameYourPrice,
                        sliderPosition = sliderPosition,
                        scrollState = scrollState,
                        showMoreOptions = showMoreOptions,
                        existingSubscriber = existingSubscriber,
                        hasTasksAccount = hasTasksAccount,
                        onSignIn = onSignIn,
                        setNameYourPrice = setNameYourPrice,
                        setPrice = setPrice,
                        subscribe = subscribe,
                        skus = skus,
                    )
                }
                Spacer(Modifier.height(KEYLINE_FIRST))
                Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
            }
        }
    }

    @Composable
    fun SponsorButton() {
        val context = LocalContext.current
        OutlinedButton(
            onClick = { context.openUri(runBlocking { getString(Res.string.url_sponsor) }) },
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier.padding(KEYLINE_FIRST, 0.dp, KEYLINE_FIRST, KEYLINE_FIRST)
        ) {
            Row {
                Icon(
                    painter = painterResource(R.drawable.ic_outline_favorite_border_24px),
                    contentDescription = null
                )
                Text(
                    text = stringResource(R.string.github_sponsor),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }

    @Composable
    fun GreetingText(resId: Int) {
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .padding(KEYLINE_FIRST, KEYLINE_FIRST, KEYLINE_FIRST, 0.dp),
            text = stringResource(resId),
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
        )
    }

    @Composable
    fun GooglePlayButtons(
        nameYourPrice: Boolean,
        sliderPosition: Float,
        scrollState: ScrollState,
        showMoreOptions: Boolean = true,
        existingSubscriber: Boolean = false,
        hasTasksAccount: Boolean = false,
        onSignIn: () -> Unit = {},
        setNameYourPrice: (Boolean) -> Unit,
        setPrice: (Float) -> Unit,
        subscribe: (Int, Boolean) -> Unit,
        skus: List<Sku>,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            HorizontalDivider(modifier = Modifier.padding(vertical = KEYLINE_FIRST))
            val loading = skus.isEmpty()
            Box(
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (loading) 0f else 1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = stringResource(R.string.pro_free_trial),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .fillMaxWidth(.75f)
                            .padding(bottom = KEYLINE_FIRST),
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                    )
                    if (nameYourPrice) {
                        NameYourPrice(
                            sliderPosition = sliderPosition,
                            setPrice = setPrice,
                            subscribe = subscribe,
                            skus = skus,
                        )
                    } else {
                        TasksAccount(
                            skus = skus,
                            subscribe = subscribe
                        )
                    }
                    if (showMoreOptions) {
                        Spacer(Modifier.height(KEYLINE_FIRST))
                        val scope = rememberCoroutineScope()
                        OutlinedButton(
                            onClick = {
                                setNameYourPrice(!nameYourPrice)
                                scope.launch {
                                    scrollState.animateScrollTo(0)
                                }
                            },
                            colors = ButtonDefaults.textButtonColors(
                                containerColor = Color.Transparent
                            )
                        ) {
                            Text(
                                text = if (nameYourPrice) {
                                    composeStringResource(Res.string.tasks_org_account)
                                } else {
                                    composeStringResource(Res.string.supporter)
                                },
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            SymbolIcon(
                                name = TasksIcons.KEYBOARD_ARROW_RIGHT,
                                contentDescription = null,
                                modifier = Modifier.padding(start = 4.dp),
                                tint = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
                if (loading) {
                    Spacer(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable(
                                interactionSource = null,
                                indication = null,
                                onClick = {}
                            )
                    )
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            if (!showMoreOptions && !existingSubscriber && !hasTasksAccount) {
                Spacer(Modifier.height(32.dp))
                Text(
                    text = composeStringResource(Res.string.sign_in_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onSignIn,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                ) {
                    Text(
                        text = composeStringResource(Res.string.sign_in),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }

    @Composable
    fun PagerItem(feature: CarouselItem) {
        Column(
            modifier = Modifier
                .width(150.dp)
                .padding(HALF_KEYLINE),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(feature.icon),
                contentDescription = null,
                modifier = Modifier.requiredSize(72.dp),
                alignment = Alignment.Center,
                colorFilter = when (feature.iconStyle) {
                    IconStyle.TINT -> ColorFilter.tint(MaterialTheme.colorScheme.onSurfaceVariant)
                    IconStyle.ORIGINAL -> null
                }
            )
            Text(
                text = stringResource(feature.title),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(0.dp, 4.dp),
                color = MaterialTheme.colorScheme.onBackground,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 0.25.sp
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(feature.description),
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onBackground,
                style = TextStyle(
                    fontSize = 12.sp,
                    letterSpacing = 0.4.sp
                ),
                textAlign = TextAlign.Center,
            )
        }
    }

    @Composable
    fun TasksAccount(
        skus: List<Sku>,
        subscribe: (Int, Boolean) -> Unit,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(KEYLINE_FIRST, 0.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                PurchaseButton(
                    price = remember(skus) {
                        skus.find { it.productId == SubscriptionSkus.sku(30) }?.price ?: "$30"
                    },
                    popperText = "${stringResource(R.string.save_percent, 16)} $POPPER",
                    onClick = { subscribe(30, false) },
                )
                Spacer(Modifier.width(KEYLINE_FIRST))
                PurchaseButton(
                    price = remember(skus) {
                        skus.find { it.productId == SubscriptionSkus.sku(3, monthly = true) }?.price ?: "$3"
                    },
                    monthly = true,
                    onClick = { subscribe(3, true) },
                )
            }
        }
    }

    @Composable
    fun PurchaseButton(
        price: String,
        monthly: Boolean = false,
        popperText: String = "",
        onClick: () -> Unit,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Button(
                onClick = { onClick() },
                colors = ButtonDefaults.textButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    text = stringResource(
                        if (monthly) R.string.price_per_month_with_currency else R.string.price_per_year_with_currency,
                        price
                    ),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            Text(
                text = popperText,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    @Composable
    fun NameYourPrice(
        sliderPosition: Float,
        setPrice: (Float) -> Unit,
        subscribe: (Int, Boolean) -> Unit,
        skus: List<Sku>,
    ) {
        val ladder = SubscriptionSkus.SUPPORTER_LADDER
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth()) {
                Slider(
                    modifier = Modifier.padding(KEYLINE_FIRST, 0.dp, KEYLINE_FIRST, HALF_KEYLINE),
                    value = sliderPosition.coerceIn(ladder.first.toFloat(), ladder.last.toFloat()),
                    onValueChange = { setPrice(it) },
                    valueRange = ladder.first.toFloat()..ladder.last.toFloat(),
                    steps = ladder.count() - 2,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.secondary,
                        activeTrackColor = MaterialTheme.colorScheme.secondary,
                        inactiveTrackColor = MaterialTheme.colorScheme.outline,
                        activeTickColor = Color.Transparent,
                        inactiveTickColor = Color.Transparent
                    )
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                val price = sliderPosition.roundToInt().coerceIn(ladder.first, ladder.last)
                PurchaseButton(
                    price = remember(skus, price) {
                        skus
                            .find { it.productId == SubscriptionSkus.sku(price) }
                            ?.price
                            ?: "$$price"
                    },
                    popperText = if (price >= 7)
                        "${stringResource(R.string.above_average, 16)} $POPPER"
                    else
                        "",
                    onClick = { subscribe(price, false) },
                )
                if (price < 3) {
                    Spacer(Modifier.width(KEYLINE_FIRST))
                    PurchaseButton(
                        price = remember(skus, price) {
                            skus
                                .find { it.productId == SubscriptionSkus.sku(price, monthly = true) }
                                ?.price
                                ?: "$$price"
                        },
                        monthly = true,
                        popperText = "${stringResource(R.string.above_average)} $POPPER",
                        onClick = { subscribe(price, true) },
                    )
                }
            }
        }
    }
}

@PreviewLightDark
@PreviewFontScale
@PreviewScreenSizes
@Composable
private fun PurchaseDialogPreview() {
    TasksTheme {
        SubscriptionScreen(
            subscribe = { _, _ -> },
            onBack = {},
            nameYourPrice = false,
            sliderPosition = 1f,
            setPrice = {},
            setNameYourPrice = {},
            skus = emptyList(),
        )
    }
}

@PreviewLightDark
@Composable
private fun NameYourPricePreview() {
    TasksTheme {
        SubscriptionScreen(
            subscribe = { _, _ -> },
            onBack = {},
            nameYourPrice = true,
            sliderPosition = 4f,
            setPrice = {},
            setNameYourPrice = {},
            skus = emptyList(),
        )
    }
}

@PreviewLightDark
@Composable
private fun UpgradeNoSubscriptionPreview() {
    TasksTheme {
        SubscriptionScreen(
            subscribe = { _, _ -> },
            onBack = {},
            nameYourPrice = false,
            showMoreOptions = false,
            sliderPosition = 1f,
            setPrice = {},
            setNameYourPrice = {},
            skus = emptyList(),
        )
    }
}

@PreviewLightDark
@Composable
private fun UpgradeExistingSubscriberPreview() {
    TasksTheme {
        SubscriptionScreen(
            subscribe = { _, _ -> },
            onBack = {},
            nameYourPrice = false,
            showMoreOptions = false,
            existingSubscriber = true,
            sliderPosition = 1f,
            setPrice = {},
            setNameYourPrice = {},
            skus = emptyList(),
        )
    }
}
