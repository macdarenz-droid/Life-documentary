package org.tasks.compose.settings

import org.tasks.themes.TasksIcons
import org.tasks.compose.components.SymbolIcon
import android.appwidget.AppWidgetManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import org.jetbrains.compose.resources.stringResource
import tasks.kmp.generated.resources.Res
import tasks.kmp.generated.resources.add_widget_to_home_screen
import org.tasks.compose.Constants
import org.tasks.kmp.org.tasks.compose.settings.SettingRow
import org.tasks.themes.TasksTheme

@Composable
fun AddWidgetToHomeRow(onClick: () -> Unit) {
    val context = LocalContext.current
    val isRequestPinAppWidgetSupported = LocalInspectionMode.current || remember {
        context.getSystemService(AppWidgetManager::class.java).isRequestPinAppWidgetSupported
    }
    if (isRequestPinAppWidgetSupported) {
        SettingRow(
            modifier = Modifier.clickable(onClick = onClick),
            left = {
                Box(
                    modifier = Modifier.size(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SymbolIcon(
                        name = TasksIcons.WIDGETS,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            center = {
                Text(
                    text = stringResource(Res.string.add_widget_to_home_screen),
                    modifier = Modifier.padding(start = Constants.KEYLINE_FIRST)
                )
            }
        )
    }
}

@Composable
@Preview(showBackground = true)
private fun AddToHomePreview() {
    TasksTheme {
        AddShortcutToHomeRow(onClick = {})
    }
}
