package org.tasks.jobs

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy.APPEND_OR_REPLACE
import androidx.work.ExistingWorkPolicy.REPLACE
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkContinuation
import androidx.work.WorkInfo
import androidx.work.WorkRequest
import androidx.work.Worker
import androidx.work.workDataOf
import com.todoroo.andlib.utility.AndroidUtilities.atLeastS
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tasks.BuildConfig
import org.tasks.R
import org.tasks.data.OpenTaskDao
import org.tasks.data.dao.CaldavDao
import org.tasks.data.entity.CaldavAccount
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_CALDAV
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_ETEBASE
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_GOOGLE_TASKS
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_MICROSOFT
import org.tasks.data.entity.CaldavAccount.Companion.TYPE_TASKS
import org.tasks.data.entity.Task
import org.tasks.date.DateTimeUtils.midnight
import org.tasks.date.DateTimeUtils.newDateTime
import org.tasks.feed.BlogFeedMode
import org.tasks.jobs.DriveUploader.Companion.EXTRA_PURGE
import org.tasks.jobs.DriveUploader.Companion.EXTRA_URI
import org.tasks.jobs.MigrateLocalWork.Companion.EXTRA_ACCOUNT
import org.tasks.jobs.MigrateLocalWork.Companion.EXTRA_LOCAL_ACCOUNT
import org.tasks.sync.SyncSource
import org.tasks.jobs.WorkManager.Companion.REMOTE_CONFIG_INTERVAL_HOURS
import org.tasks.jobs.WorkManager.Companion.TAG_BACKGROUND_SYNC
import org.tasks.jobs.WorkManager.Companion.TAG_BACKUP
import org.tasks.jobs.WorkManager.Companion.TAG_MIGRATE_LOCAL
import org.tasks.jobs.WorkManager.Companion.TAG_NOTIFICATIONS
import org.tasks.jobs.WorkManager.Companion.TAG_REFRESH
import org.tasks.jobs.WorkManager.Companion.TAG_REMOTE_CONFIG
import org.tasks.jobs.WorkManager.Companion.TAG_BLOG_FEED
import org.tasks.jobs.WorkManager.Companion.TAG_SYNC
import org.tasks.jobs.WorkManager.Companion.TAG_UPDATE_PURCHASES
import org.tasks.notifications.Throttle
import org.tasks.preferences.Preferences
import org.tasks.preferences.TasksPreferences
import org.tasks.time.DateTimeUtils2.currentTimeMillis
import org.tasks.time.printTimestamp
import timber.log.Timber
import java.util.Random
import java.util.concurrent.TimeUnit
import kotlin.math.max

class WorkManagerImpl(
    private val context: Context,
    private val preferences: Preferences,
    private val tasksPreferences: TasksPreferences,
    private val caldavDao: CaldavDao,
    private val openTaskDao: OpenTaskDao,
): WorkManager {
    private val throttle = Throttle(200, 60000, "WORK")
    private val alarmManager: AlarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private val workManager = androidx.work.WorkManager.getInstance(context)

    override fun updateCalendar(task: Task) {
        enqueue(
            OneTimeWorkRequest.Builder(UpdateCalendarWork::class.java)
                .setInputData(UpdateCalendarWork.EXTRA_ID to task.id)
        )
    }

    @SuppressLint("EnqueueWork")
    override fun migrateLocalTasks(localAccount: CaldavAccount, tasksAccount: CaldavAccount) {
        val builder = OneTimeWorkRequest.Builder(MigrateLocalWork::class.java)
                .setInputData(
                    EXTRA_LOCAL_ACCOUNT to localAccount.uuid,
                    EXTRA_ACCOUNT to tasksAccount.uuid,
                )
                .setConstraints(networkConstraints)
        enqueue(workManager.beginUniqueWork(TAG_MIGRATE_LOCAL, APPEND_OR_REPLACE, builder.build()))
    }

    override suspend fun startEnqueuedSync() {
        if (getSyncJob().any { it.state == WorkInfo.State.ENQUEUED }) {
            sync(SyncSource.APP_BACKGROUND)
        }
    }

    @SuppressLint("EnqueueWork")
    override suspend fun sync(source: SyncSource) {
        val immediate = source.immediate
        val builder = OneTimeWorkRequest.Builder(SyncWork::class.java)
                .setInputData(SyncWork.EXTRA_SOURCE to source.name)
        if (!openTaskDao.shouldSync()) {
            builder.setConstraints(networkConstraints)
        }
        if (!immediate) {
            builder.setInitialDelay(SYNC_CHANGE_DEBOUNCE_SECONDS, TimeUnit.SECONDS)
        }
        val append = getSyncJob().any { it.state == WorkInfo.State.RUNNING }
        Timber.d("sync source=$source immediate=$immediate append=$append")
        enqueue(workManager.beginUniqueWork(
                TAG_SYNC,
                if (append) APPEND_OR_REPLACE else REPLACE,
                builder.build())
        )
    }

    override fun updateBackgroundSync() {
        throttle.run {
            val enabled = caldavDao.getAccounts(
                TYPE_GOOGLE_TASKS,
                TYPE_CALDAV,
                TYPE_TASKS,
                TYPE_ETEBASE,
                TYPE_MICROSOFT
            ).isNotEmpty()
            if (enabled) {
                Timber.d("Enabling background sync")
                val builder = PeriodicWorkRequest.Builder(SyncWork::class.java, 1, TimeUnit.HOURS)
                    .setInputData(SyncWork.EXTRA_SOURCE to SyncSource.BACKGROUND.name)
                    .setConstraints(networkConstraints)
                workManager.enqueueUniquePeriodicWork(
                    TAG_BACKGROUND_SYNC,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    builder.build()
                )
            } else {
                Timber.d("Disabling background sync")
                workManager.cancelUniqueWork(TAG_BACKGROUND_SYNC)
            }
        }
    }

    override suspend fun scheduleRefresh(timestamp: Long) =
        enqueueUnique(TAG_REFRESH, RefreshWork::class.java, timestamp)

    override fun triggerNotifications(expedited: Boolean) {
        enqueueUnique(
            TAG_NOTIFICATIONS,
            NotificationWork::class.java,
            time = if (expedited) 0 else currentTimeMillis() + 5_000,
            expedited = expedited,
        )
    }

    override fun scheduleNotification(scheduledTime: Long) {
        val time = max(currentTimeMillis(), scheduledTime)
        if (time < currentTimeMillis()) {
            triggerNotifications(expedited = true)
        } else {
            val pendingIntent = notificationPendingIntent
            if (!atLeastS() || alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pendingIntent)
            }
        }
    }

    override fun scheduleBackup() =
            enqueueUnique(
                    TAG_BACKUP,
                    BackupWork::class.java,
                    newDateTime(preferences.getLong(R.string.p_last_backup, 0L))
                            .plusDays(1)
                            .millis
                            .coerceAtMost(midnight()))

    override fun scheduleConfigRefresh() {
        throttle.run {
            workManager.enqueueUniquePeriodicWork(
                    TAG_REMOTE_CONFIG,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    PeriodicWorkRequest.Builder(
                            RemoteConfigWork::class.java, REMOTE_CONFIG_INTERVAL_HOURS, TimeUnit.HOURS)
                            .setConstraints(networkConstraints)
                            .build())
        }
    }

    override fun scheduleDriveUpload(uri: Uri, purge: Boolean) {
        if (!preferences.getBoolean(R.string.p_google_drive_backup, false)) {
            return
        }
        val builder = OneTimeWorkRequest.Builder(DriveUploader::class.java)
            .setInputData(
                EXTRA_URI to uri.toString(),
                EXTRA_PURGE to purge,
            )
            .setConstraints(networkConstraints)
        if (purge) {
            builder.setInitialDelay(Random().nextInt(3600).toLong(), TimeUnit.SECONDS)
        }
        enqueue(builder)
    }

    override fun updatePurchases() =
        enqueueUnique(TAG_UPDATE_PURCHASES, UpdatePurchaseWork::class.java)

    override suspend fun scheduleBlogFeedCheck() {
        val mode = BlogFeedMode.fromValue(
            tasksPreferences.get(TasksPreferences.blogFeedMode, BlogFeedMode.ANNOUNCEMENTS.value)
        )
        if (mode == BlogFeedMode.NONE) {
            workManager.cancelUniqueWork(TAG_BLOG_FEED)
            return
        }
        val lastChecked = tasksPreferences.get(TasksPreferences.blogLastChecked, 0L)
            .takeIf { it > 0 }
            ?: currentTimeMillis()
            .also { tasksPreferences.set(TasksPreferences.blogLastChecked, it) }
        val time = lastChecked + TimeUnit.HOURS.toMillis(WorkManager.BLOG_FEED_INTERVAL_HOURS)
        val overdue = currentTimeMillis() - lastChecked > TimeUnit.DAYS.toMillis(7)
        enqueueUnique(
            TAG_BLOG_FEED,
            BlogFeedWork::class.java,
            time,
            constraints = if (overdue) networkConstraints else blogFeedConstraints,
            backoffPolicy = BackoffPolicy.EXPONENTIAL,
        )
    }

    @SuppressLint("EnqueueWork")
    private fun enqueueUnique(
        key: String,
        c: Class<out Worker?>,
        time: Long = 0,
        expedited: Boolean = false,
        constraints: Constraints? = null,
        backoffPolicy: BackoffPolicy? = null,
    ) {
        val delay = time - currentTimeMillis()
        val builder = OneTimeWorkRequest.Builder(c)
        if (delay > 0) {
            builder.setInitialDelay(delay, TimeUnit.MILLISECONDS)
        }
        if (expedited) {
            builder.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
        }
        if (constraints != null) {
            builder.setConstraints(constraints)
        }
        if (backoffPolicy != null) {
            builder.setBackoffCriteria(backoffPolicy, 1, TimeUnit.HOURS)
        }
        val scheduledFor = if (delay > 0) time else currentTimeMillis()
        Timber.d("$key: expedited=$expedited ${printTimestamp(scheduledFor)} (${printDuration(delay)})")
        enqueue(workManager.beginUniqueWork(key, REPLACE, builder.build()))
    }

    private fun enqueue(builder: WorkRequest.Builder<*, *>) {
        throttle.run {
            workManager.enqueue(builder.build())
        }
    }

    private fun enqueue(continuation: WorkContinuation) {
        throttle.run {
            continuation.enqueue()
        }
    }

    private val notificationPendingIntent: PendingIntent
        get() = PendingIntent.getBroadcast(
            context,
            0,
            Intent(context, NotificationReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private suspend fun getSyncJob() = withContext(Dispatchers.IO) {
        workManager.getWorkInfosForUniqueWork(TAG_SYNC).get()
    }
}

private const val SYNC_CHANGE_DEBOUNCE_SECONDS = 30L

private fun <B : WorkRequest.Builder<B, *>, W : WorkRequest> WorkRequest.Builder<B, W>.setInputData(
    vararg pairs: Pair<String, Any?>
): B = setInputData(workDataOf(*pairs))

private fun printDuration(millis: Long): String = if (BuildConfig.DEBUG) {
    val seconds = millis / 1000
    String.format(
        "%dh %dm %ds", seconds / 3600L, (seconds % 3600L / 60L).toInt(), (seconds % 60L).toInt())
} else {
    millis.toString()
}

val networkConstraints: Constraints
    get() = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

val blogFeedConstraints: Constraints
    get() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.UNMETERED)
        .setRequiresCharging(true)
        .build()
