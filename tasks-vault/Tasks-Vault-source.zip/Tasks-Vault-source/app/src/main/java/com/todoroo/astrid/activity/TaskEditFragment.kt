package com.todoroo.astrid.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.fragment.compose.content
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.todoroo.astrid.activity.MainActivity.Companion.finishAffinity
import com.todoroo.astrid.activity.MainActivity.Companion.removeTask
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import org.tasks.calendars.CalendarPicker
import org.tasks.compose.edit.TaskEditScreen
import org.tasks.repeats.BasicRecurrenceDialog
import org.tasks.repeats.RepeatRuleToString
import org.tasks.data.dao.UserActivityDao
import org.tasks.dialogs.Linkify
import org.tasks.extensions.hideKeyboard
import org.tasks.markdown.MarkdownProvider
import org.tasks.notifications.CancelReason
import org.tasks.notifications.NotificationManager
import org.tasks.play.PlayServices
import org.tasks.preferences.Preferences
import org.tasks.themes.TasksTheme
import org.tasks.themes.Theme
import org.tasks.ui.ChipProvider
import org.tasks.ui.TaskEditViewModel
import timber.log.Timber
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class TaskEditFragment : Fragment() {
    @Inject lateinit var userActivityDao: UserActivityDao
    @Inject lateinit var notificationManager: NotificationManager
    @Inject lateinit var preferences: Preferences
    @Inject lateinit var linkify: Linkify
    @Inject lateinit var locale: Locale
    @Inject lateinit var chipProvider: ChipProvider
    @Inject lateinit var playServices: PlayServices
    @Inject lateinit var theme: Theme
    @Inject lateinit var repeatRuleToString: RepeatRuleToString

    private val editViewModel: TaskEditViewModel by viewModels()
    private val mainViewModel: MainActivityViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        parentFragmentManager.setFragmentResultListener(
            CalendarPicker.REQUEST_KEY, this
        ) { _, bundle ->
            editViewModel.setCalendar(bundle.getString(CalendarPicker.EXTRA_CALENDAR_ID))
        }
        parentFragmentManager.setFragmentResultListener(
            BasicRecurrenceDialog.REQUEST_KEY, this
        ) { _, bundle ->
            editViewModel.setRecurrence(bundle.getString(BasicRecurrenceDialog.EXTRA_RRULE))
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ) = content {
        TasksTheme(
            theme = theme.themeBase.index,
            primary = theme.themeColor.primaryColor,
        ) {
            val viewState = editViewModel.viewState.collectAsStateWithLifecycle().value
            LaunchedEffect(viewState.isNew) {
                if (!viewState.isNew) {
                    notificationManager.cancel(viewState.task.id, CancelReason.EDIT)
                }
            }
            val context = LocalContext.current
            val keyboard = LocalSoftwareKeyboardController.current

            TaskEditScreen(
                editViewModel = editViewModel,
                viewState = viewState,
                comments = userActivityDao
                    .watchComments(viewState.task.uuid)
                    .collectAsStateWithLifecycle(emptyList())
                    .value,
                save = {
                    keyboard?.hide()
                    lifecycleScope.launch { save() }
                },
                discard = {
                    keyboard?.hide()
                    discard()
                },
                delete = {
                    keyboard?.hide()
                    lifecycleScope.launch {
                        editViewModel.delete()
                        clearTask()
                    }
                },
                dismissBeastMode = { editViewModel.hideBeastModeHint(click = false) },
                deleteComment = {
                    lifecycleScope.launch {
                        userActivityDao.delete(it)
                    }
                },
                markdownProvider = remember { MarkdownProvider(context, preferences) },
                linkify = if (viewState.linkify) linkify else null,
                preferences = preferences,
                onClickRepeat = {
                    val vs = editViewModel.viewState.value
                    BasicRecurrenceDialog.newBasicRecurrenceDialog(
                        rrule = vs.task.recurrence,
                        dueDate = editViewModel.dueDate.value,
                        accountType = vs.list.account.accountType,
                    ).show(parentFragmentManager, FRAG_TAG_BASIC_RECURRENCE)
                },
                repeatRuleToString = { repeatRuleToString.toStringBlocking(it) },
                colorProvider = { chipProvider.getColor(it) },
                locale = remember { locale },
            )
        }
    }

    private fun clearTask() {
        Timber.d("clearTask()")
        mainViewModel.setTask(null)
        activity?.let { activity ->
            activity.hideKeyboard()
            when {
                activity.intent.finishAffinity -> {
                    Timber.d("finishAffinity")
                    activity.finishAffinity()
                }
                activity.intent.removeTask -> {
                    Timber.d("removeTask")
                    activity.moveTaskToBack(true)
                    activity.finish()
                }
            }
        }
    }

    suspend fun save(remove: Boolean = true) {
        editViewModel.save()
        if (remove) {
            clearTask()
        }
        activity?.let { playServices.requestReview(it) }
    }

    private fun discard() = lifecycleScope.launch {
        editViewModel.discard()
        clearTask()
    }

    companion object {
        const val EXTRA_TASK = "extra_task"

        const val FRAG_TAG_CALENDAR_PICKER = "frag_tag_calendar_picker"
        private const val FRAG_TAG_BASIC_RECURRENCE = "frag_tag_basic_recurrence"
    }
}
