### 15.13 (2026-10-13)

* Update icon set and add 1,800+ icons
* Reduced app download and install size
* Skip invalid tasks instead of stopping sync
* Restrict credentials to account domain
* Handle secondly recurrence intervals
* Microsoft To Do sync fixes
* Use sentence case for 'Clear completed' - @joshuagrady [#4214](https://github.com/tasks/tasks/pull/4214)
* Bug fixes and performance improvements

Android:
  * DAVx5 sync fixes

Desktop:
  * Sign Windows releases
  * New desktop beta channel at https://download.tasks.org/beta
  * Fix Intel Mac and Windows ARM builds
  * Fix .deb installs on older distros

Update translations:
  * Brazilian Portuguese - @restlessSangoLeelo, @gregcarmo
  * Bulgarian - 109247019824
  * Chinese (Simplified) - hamburger2048, Sketch6580
  * Dutch - @Stephan-P
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @Kachelkaiser
  * Indonesian - @arifpedia
  * Italian - @glemco
  * Japanese - Norara
  * Persian - @ali-0315
  * Romanian - @ygorigor
  * Russian - George Shchennikov
  * Serbian - @vale-decem
  * Turkish - @oersen
  * Ukrainian - @IhorHordiichuk

### 15.12 (2026-09-11)

* Add 'Works with Tasks.org' in app settings
* Sync reminder dismissals across devices
* Don't bump modification date when snoozing

Android:
  * Add new content provider API and [specification](https://github.com/tasks/tasks/blob/main/CONTENT_PROVIDER.md)
    * Build your own widgets, apps, and tools with the Tasks.org data on your device
  * Reduce sync delay after changes from 60 to 30 seconds
  * Add support for AppFunctions

Desktop:
  * Add an MCP server
    * Allows AI assistants to connect to Tasks.org
  * Look & feel settings - @jheld [#4360](https://github.com/tasks/tasks/pull/4360)
  * Navigation drawer settings - @jheld [#4407](https://github.com/tasks/tasks/pull/4407)
  * Theme fixes and updates
  * Fix stale times [#4663](https://github.com/tasks/tasks/issues/4663)

Update translations:
  * Chinese (Simplified) - hamburger2048
  * Dutch - @Stephan-P
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @fm-sys, @felicia-b @Kachelkaiser
  * Hungarian - Kaci
  * Romanian - @ygorigor
  * Turkish - @oersen

### 15.11 (2026-09-01)

* Add 'last day of month' recurrence option [#2411](https://github.com/tasks/tasks/issues/2411)
* Drawer rendering performance improvement - @toxicphreAK [#4570](https://github.com/tasks/tasks/pull/4570)
* Fix running tests on Windows - @przemhb [#4591](https://github.com/tasks/tasks/pull/4591)
* Make sure recurrence doesn't skip short months [#4135](https://github.com/tasks/tasks/issues/4135)
* Fix all-day dates edited across two devices and two time zones from wedging sync

Desktop:
  * Display reminders on macOS, Windows, and Linux
  * Fix packaging app from source - @CR0CKER [#4589](https://github.com/tasks/tasks/pull/4589)

Android:
  * Task list rendering performance improvement - @toxicphreAK [#4569](https://github.com/tasks/tasks/pull/4569)
  * Fix time display when ICU data is missing

Update translations:
  * Brazilian Portuguese - @restlessSangoLeelo
  * Czech - @p-bo
  * Esperanto - @Rajzin
  * Estonian - Priit Jõerüüt
  * Hungarian - Kaci
  * Indonesian - @arifpedia
  * Romanian - @ygorigor
  * Serbian - @vale-decem
  * Swedish - Jonatan Nyberg
  * Thai - @KuroisKitsune
  * Ukrainian - @IhorHordiichuk

### 15.10 (2026-08-14)

* Completed subtasks now remain under the parent task
* Add 'Show completed subtasks' toggle to sort menu
* Subtask sorting bug fixes

Desktop:
  * Add subtasks to the edit screen
    * Supports drag and drop to reorder and nest
    * Tab and shift-tab to change nesting
    * Edit subtask titles from the parent task
    * Edit subtasks without leaving the parent task
  * Add Task defaults settings page
  * Prompt before discarding or deleting tasks from the editor
  * Fix Windows and Linux ARM builds
  * Fix window size crashes on Windows
  * Fix desktop app losing subscription status

Update translations:
  * Brazilian Portuguese - @restlessSangoLeelo
  * Chinese (Simplified) - Sketch6580, hamburger2048
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @zhx000
  * Hebrew - @ginger-co, @omeritzics
  * Japanese - akira7095
  * Polish - @pawerak
  * Turkish - @oersen

### 15.9.1 (2026-08-05)

* Google Tasks sync performance improvements
* Add default reminders to incoming Google Tasks
* Detect moves from native Google Task apps
* Prevent stuck dirty tasks from causing a sync loop
* Task list scrolling performance improvements
* Logging performance improvements - @toxicphreAK

Android:
  * OpenTask query hardening - @toxicphreAK [#4539](https://github.com/tasks/tasks/pull/4539)
  * Collapsed grouping fix for Pebble watches

Update translations:
  * Bulgarian - 109247019824
  * Estonian - Priit Jõerüüt

### 15.9 (2026-08-05)

* Fix modified and created timestamp sync
* Fix language override not being applied

Desktop:
  * Add Microsoft To Do support
  * New edit screen functionality
    * Start dates
    * Due dates
    * Notifications
    * Recurrence
  * Make drawer, task list, and edit screens resizable
  * Add bottom bar to edit screen with complete, discard, and delete actions
  * Add encrypted cookie storage
  * Fix tag picker automatically selecting tags

Android:
  * Disable swipe-to-snooze for location reminders
  * Pagination improvements for Pebble watches
  * 'Show checkboxes' widget option refreshes immediately [#4494](https://github.com/tasks/tasks/issues/4494)

Update translations:
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580, hamburger2048
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @zhx000
  * Italian - @ppasserini
  * Japanese - Norara
  * Polish - @pawerak
  * Russian - @PONYATIN
  * Serbian - @vale-decem
  * Swedish - Jonatan Nyberg
  * Turkish - @oersen

### 15.8 (2026-07-22)

* Sync tag info
  * Sync tag colors, icons, and order across devices
  * Renaming or deleting tags syncs across devices
  * Requires Tasks.org Cloud or CalDAV with compatible CalDAV server
  * Opt-in for CalDAV accounts - enable in account settings
* Don't add default reminders to tasks from Nextcloud Tasks 0.17+ [#4498](https://github.com/tasks/tasks/issues/4498)
* Fix database migration crash

Desktop:
  * Add tag picker to edit screen
  * Add priority picker to edit screen
  * Add tag settings screen
  * Fix backstack crash

Android:
  * Fix DAVx5 sync loop [#4496](https://github.com/tasks/tasks/issues/4496)

Update translations
  * Brazilian Portuguese - @gregcarmo
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580, hamburger2048
  * Czech - Fjuro
  * Danish - ERYpTION
  * French - @FlorianLeChat
  * Serbian - @vale-decem
  * Spanish - @FlorianLeChat

### 15.7.4 (2026-07-10)

* Disable reminder sync for OpenXchange (mailbox.org)
  * Prevents OpenXchange from deleting reminders
* Fix reminders being changed or removed after sync (DAVx5/EteSync/DecSync CC)

### 15.7.3 (2026-07-05)

* Sync performance improvements and bug fixes
* Tag settings screen design update
* Prevent duplicate tags
* Improve CalDAV homeset discovery [#4000](https://github.com/tasks/tasks/issues/4000)
* Fix tag rename synchronization [#1672](https://github.com/tasks/tasks/issues/1672)
* Fix tag sync in DAVx5/EteSync/DecSync CC [#3011](https://github.com/tasks/tasks/issues/3011)
* Fix moving tasks with subtasks in DAVx5/EteSync/DecSync CC [#2895](https://github.com/tasks/tasks/issues/2895)
* Don't change modification timestamp when moving tasks [#3407](https://github.com/tasks/tasks/issues/3047)
* Don't change modification timestamp when expanding/collapsing subtasks [#2302](https://github.com/tasks/tasks/issues/2302)
* Update translations
  * Chinese (Simplified) - Sketch6580, hamburger2048
  * Croatian - @milotype
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * Portuguese - @SantosSi
  * Turkish - @oersen

### 15.7.2 (2026-06-17)

* Sync improvements and bug fixes
* Google Tasks: advance recurring task when completed remotely [#1808](https://github.com/tasks/tasks/issues/1808)
* Fix flattening subtasks when moving between lists [#2150](https://github.com/tasks/tasks/issues/2150)

Desktop:
  * Improve Google Tasks account setup [#4434](https://github.com/tasks/tasks/issues/4434)

Update translations:
  * Brazilian Portuguese - @gregcarmo
  * Chinese (Simplified) - hamburger2048
  * Czech - Fjuro
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @franconian
  * Hebrew - @ginger-co
  * Indonesian - @arifpedia
  * Italian - @ppasserini
  * Polish - @Antmajgra
  * Turkish - @oersen

### 15.7.1 (2026-06-10)

Android:
  * New onboarding for Tasks.org Cloud
  * Fix task list losing scroll position [#4113](https://github.com/tasks/tasks/issues/4113)
  * Fix link click handling [#4423](https://github.com/tasks/tasks/issues/4423)
  * Fix list for new task shortcuts [#4022](https://github.com/tasks/tasks/issues/4022)
  * Fix duplicated tasks when importing backup file

Desktop:
  * ARM support for Windows and Linux
  * Self-signed SSL support [#4422](https://github.com/tasks/tasks/issues/4422)
  * Minor keychain improvements [#4402](https://github.com/tasks/tasks/issues/4402)

Update translations:
  * Chinese (Simplified) - Sketch6580, hamburger2048
  * Czech - Fjuro
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @ColorfulRhino
  * Icelandic - @gissur1-hash
  * Italian - @albanobattistella
  * Japanese - Norara
  * Russian - @efrolovdev
  * Swedish - Mona Lisa
  * Turkish - @emintufan

### 15.6 (2026-05-25)

* Create new lists from the list picker
* Improve CalDAV color sync compatibility - @poke [#4387](https://github.com/tasks/tasks/pull/4387)
* Fix notifications being cancelled on sync [#4386](https://github.com/tasks/tasks/issues/4386)
* Handle missing timestamps in iCalendar data [#4389](https://github.com/tasks/tasks/issues/4389)
* Add subtitles to disambiguate accounts in drawer
* Updated list settings screens

Desktop:
  * Add list picker to task edit screen
  * Create, update, and delete lists
  * Use currently viewed list when adding new tasks
  * Add ability to log out of Google Task accounts
  * Prompt to create list if there is none
  * Remember drawer/rail state across launch
  * Prevent launching multiple instances
  * Use TASKS_DATA_DIR env var to override data storage
  * Use platform conventions for app data and logs [#4373](https://github.com/tasks/tasks/issues/4373)
  * Fix crash on Windows when waking from sleep [#4368](https://github.com/tasks/tasks/issues/4368)

Android:
  * Add support for Infomaniak kSync

Update translations:
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, Sketch6580
  * Czech - Fjuro
  * French - @FlorianLeChat
  * German - @franconian
  * Italian - @ppasserini
  * Japanese - Norara
  * Spanish - @Nikzouls
  * Turkish - @emintufan

### 15.5 (2026-05-15)

Desktop:
  * Add Google Tasks support
  * Close task before opening another one
  * Focus keyboard on title when creating new task

Android:
  * Fix tag sync for DAVx5/EteSync/DecSync CC

Update translations:
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, Sketch6580
  * Croatian - @milotype
  * Czech - Fjuro
  * French - @FlorianLeChat
  * Romanian - @ygorigor
  * Swedish - Mona Lisa
  * Turkish - @emintufan

### 15.4.2 (2026-05-08)

Desktop:
  * Fix EteSync setup
  * Add 'About' screen

Android:
  * Improve notifications on wearables

Update translations:
  * Chinese (Simplified) - Sketch6580
  * Czech - Fjuro
  * French - @FlorianLeChat
  * Turkish - @oersen

### 15.4.1 (2026-05-06)

Desktop:
  * Fix Windows exe download link
  * Add AppImage download link

### 15.4 (2026-05-06)

Desktop:
  * Add CalDAV support
  * Add EteSync support
  * Unlock desktop app with Google Play subscription or GitHub Sponsorship
  * Fix opening URLs on some platforms [#4326](https://github.com/tasks/tasks/issues/4326)
  * Generate AppImage for Linux [#4327](https://github.com/tasks/tasks/issues/4327)

Android:
  * QR code scanner to unlock desktop (Google Play only)
  * Updated DAVx5, CalDAV, and EteSync settings screens

Update translations:
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580, 大王叫我来巡山
  * Czech - Fjuro, Odweta
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @ColorfulRhino, @CrUsHoR
  * Hindi - Chandra Mohan Jha
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - Norara
  * Kurdish (Northern) - @CYAXXX
  * Turkish - @oersen, @emintufan

### 15.3 (2026-04-23)

Desktop:
  * Create new tasks
  * Add title and description support
  * Added top level settings screen
  * Tasks.org account settings
  * Local account settings
  * Improve push sync reliability

Android:
  * Clear notification when completed/deleted remotely [#4302](https://github.com/tasks/tasks/pull/4302)
  * Geofence battery improvements
  * Fix parent relationship lost when importing backups [#4301](https://github.com/tasks/tasks/issues/4301)
  * Fix failure when importing older backups [#4293](https://github.com/tasks/tasks/issues/4293)

Update translations:
  * Chinese (Simplified) - Sketch6580, 大王叫我来巡山
  * Czech - Fjuro
  * French - @FlorianLeChat, @tlabartbarnagaud
  * German - @ColorfulRhino, Carlo Kisser
  * Hindi - Chandra Mohan Jha
  * Hungarian - Kaci
  * Indonesian - @arifpedia
  * Italian - @albanobattistella
  * Japanese - Norara
  * Russian - @PONYATIN
  * Swedish - Mona Lisa
  * Turkish - @emintufan

### 15.2.1 (2026-04-10)

* Pre-alpha desktop release for macOS, Windows, and Linux! [#1256](https://github.com/tasks/tasks/issues/1256)
  * Currently only supports Tasks.org cloud sign in
  * Early adopters only! This is a minimally useful product right now
  * Windows release not cryptographically signed yet
* Obtainium support [#2040](https://github.com/tasks/tasks/issues/2040)
* Location reminder improvements
  * Tasks.org can now register for background location updates to improve reliability
* Sync iCalendar modification times [#2083](https://github.com/tasks/tasks/issues/2083)
* Show announcements from the Tasks.org blog
* Fix many Microsoft To Do sync bugs [#4273](https://github.com/tasks/tasks/issues/4273)
* Fix bug causing iCalendar parent loss on initial sync [#3023](https://github.com/tasks/tasks/issues/3023)
* Fix DST bug [#4265](https://github.com/tasks/tasks/issues/4265)
* Fix long sync indicators
* Fix 24-hour mode for future due dates
* Update translations
  * Afrikaans - @evangibson66
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山
  * Czech - Fjuro
  * Dutch - Bram Schoenmakers
  * Esperanto - Don Zouras
  * Finnish - @pHamala
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - Norara

** 15.2 was a Google Play beta that accidentally released to F-Droid **

### 15.1 (2026-03-17)

* Add 'Per-list sorting' - @repparw
  * Toggle on '⚙ > App settings > Task list options > Per-list sorting'
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - @xlionjuan
  * Croatian - @milotype
  * Czech - Fjuro
  * Esperanto - Don Zouras
  * French - @FlorianLeChat
  * German - @Atalanttore, @Kachelkaiser, @ColorfulRhino
  * Hebrew - Xo
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Malagasy - @HairEureka160
  * Turkish - @emintufan

### 15.0 (2026-03-04)

* Friends & Family Sharing
  * Tasks.org cloud users can invite five guests to access shared lists for free
  * Guests can use Tasks.org, Apple Reminders, or any third-party CalDAV client
* Updated chip styles
* Fix group by list headers on WearOS
* Update translations
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - @xlionjuan
  * Czech - Fjuro
  * Estonian - Priit Jõerüüt
  * Finnish - @pHamala
  * French - @FlorianLeChat
  * German - @ColorfulRhino
  * Italian - @ppasserini
  * Japanese - Norara
  * Serbian - @vale-decem

### 14.15 (2026-02-25)

* Wear OS improvements
  * Wear OS app works over WiFi now [#3960](https://github.com/tasks/tasks/issues/3960)
  * Configure group and sort mode
  * Fix connection issues [#3604](https://github.com/tasks/tasks/issues/3604)
* Add Wear OS complications [#3765](https://github.com/tasks/tasks/issues/3765)
  * 'Progress' complication
  * 'Next task' complication
  * 'Add task' complication
  * 'Task count' complication
  * 'Shortcut' complication
* Default to calendar picker when autoclose is enabled
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Croatian - @milotype
  * Czech - Fjuro
  * Dutch - Bram Schoenmakers
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @ColorfulRhino
  * Hungarian - Kaci
  * Japanese - Norara
  * Turkish - @oersen

### 14.14 (2026-02-21)

* Update navigation drawer design
* Update color palettes
* Swipe to dismiss banners
* Improved sharing for new lists
* Update translations
  * Croatian - @milotype
  * Danish - ERYpTION
  * Estonian - Priit Jõerüüt
  * Turkish - @emintufan

### 14.13 (2026-02-16)

* New design for app settings screens
* Improve notifications for all day tasks [#4152](https://github.com/tasks/tasks/issues/4152)
  * Updated 'Settings > Notifications > All day tasks' section
* Don't configure notification channels to bypass DnD [#4030](https://github.com/tasks/tasks/discussions/4030)
  * Only applies to new installs going forward
* Moved 'Badges' preference to 'Advanced'
* Fix rotation bug [#3009](https://github.com/tasks/tasks/issues/3009)
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Croatian - @milotype
  * Czech - Fjuro
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @ColorfulRhino
  * Hungarian - Kaci
  * Italian - @ppasserini, @glemco
  * Japanese - @array

### 14.12 (2026-02-11)

* Email-to-task for Tasks.org accounts
  * Send email to a private address and it instantly appears in your Tasks.org
    account
* Don't show indicator for background syncs
* Change 'Repeats from' to a toggle button
* Fix price buttons showing 'Free' [#4155](https://github.com/tasks/tasks/issues/4155)
* Fix crash on startup [#4153](https://github.com/tasks/tasks/issues/4153)
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, Sketch6580
  * Czech - Fjuro
  * French - @FlorianLeChat
  * German - @ColorfulRhino
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - Norara, @array
  * Serbian - @vale-decem

### 14.11 (2026-02-05)

* Set custom default reminders [#1848](https://github.com/tasks/tasks/issues/1848)
* Push sync for Tasks.org accounts (Google Play only)
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * German - @franconian, @Kachelkaiser
  * Hungarian - Kaci
  * Japanese - Norara
  * Serbian - @vale-decem
  * Turkish - @emintufan

### 14.10 (2026-02-03)

* Improved custom reminders
  * Configure reminders relative to start date or due date
  * Configure period before or after date
* Fix drawer customization layout
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, @xlionjuan
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @Kachelkaiser, @ColorfulRhino
  * Italian - @ppasserini

### 14.9.2 (2026-02-01)

* Onboarding improvements

### 14.9.1 (2026-01-30)

* Fix F-Droid sync
* Add banner when subscription required
* Update translations
  * Bulgarian - 109247019824
  * Czech - Fjuro
  * Danish - ERYpTION
  * Dutch - Bram Schoenmakers
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @Atalanttore
  * German - @Colorful Rhino
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - Norara
  * Swedish - @Nicklasfox
  * Turkish - @oersen

### 14.9 (2026-01-24)

* New Terms of Service [blog post](https://tasks.org/blog/terms-of-service)
* Onboarding improvements
* Fix DAVx5 sync error
* Performance improvements
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, Sketch6580
  * Czech - Fjuro
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @Atalanttore
  * Greek - Clio Germanou
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - @f1047
  * Turkish - @emintufan

### 14.8.5 (2026-01-09)

* Widget performance improvements
* What's New now opens changelog on GitHub
* Fix automatically opening keyboard for new tasks [#4035](https://github.com/tasks/tasks/issues/4035)
* Fix parent-child cycle causing crash [#4065](https://github.com/tasks/tasks/issues/4065)
* Fix state restoration issue [#4025](https://github.com/tasks/tasks/issues/4025)
* Fix all day calendar entries created on previous day
* Fix Microsoft To Do and Google Task sync errors
* Fix multiple icons missing from widget
* Update translations
  * Arabic - @fahedoudeh
  * Portuguese - Paulo
  * Vietnamese - @ngocanhtve

### 14.8.4 (2025-12-20)

* Fix flashing widgets [#3902](https://github.com/tasks/tasks/issues/3902)
* Fix random reminder scheduling
* Fix random reminders firing immediately on recurring tasks [#3904](https://github.com/tasks/tasks/issues/3904)
* Fix deadlock when adding new task
* Fix crash in settings when backup location unavailable [#3989](https://github.com/tasks/tasks/issues/3989)
* Fix Hebrew and Indonesian support [#3928](https://github.com/tasks/tasks/issues/3928)
* Update translations
  * Asturian - Xana
  * Bosnian - @hasak
  * Finnish - @pHamala
  * Indonesian - @erigmac
  * Japanese - @array, Norara
  * Persian - @theuser17
  * Romanian - @ygorigor

### 14.8.3 (2025-09-16)

* Fix crash on Android 10 and below

### 14.8.2 (2025-09-14)

* Fix blank widgets on Android 16 QPR1 [#3847](https://github.com/tasks/tasks/issues/3847)
* Fix all-day calendar events [#1534](https://github.com/tasks/tasks/issues/1534)
* Fix alarm synchronization [#3859](https://github.com/tasks/tasks/issues/3859)
* Fix sync failure when migrating data from EteSync to CalDAV [#3869](https://github.com/tasks/tasks/issues/3869)
* Fix removing values from Microsoft To Do [#3862](https://github.com/tasks/tasks/issues/3862)
* Fix share invites for Nextcloud [#2386](https://github.com/tasks/tasks/issues/2386)
* Fix failure to delete source data when moving to Google Tasks [#3867](https://github.com/tasks/tasks/issues/3867)
* Fix crash when clearing completed while grouping by lists
* Update translations
  * Croatian - @milotype
  * Dutch - @fvbommel
  * German - @MisterTechnik
  * Italian - @glemco
  * Serbian - @vale-decem

### 14.8.1 (2025-08-24)

* System bar scrim improvements
* Recover from Google Task 'Bad request' errors
* Improve layout on Z Folds
* Crash fixes
* Update translations
  * Brazilian Portuguese - odnankenobi
  * Catalan - @Crashillo, @ferranpujolcamins
  * Danish - ERYpTION
  * Esperanto - Don Zouras
  * Galician - @Crashillo, @delthia
  * Hungarian - @Antmajgra, @gthrepwood
  * Italian - @ppasserini
  * Korean - Jiho Min
  * Polish - @Antmajgra
  * Portuguese - @Crashillo
  * Russian - Алексей Ежков
  * Spanish - @Crashillo

### 14.8 (2025-08-02)

* Synchronize **list** icons for Tasks.org and CalDAV accounts
  * Does not apply to Microsoft To Do, Google Tasks, DAVx5, EteSync, or DecSync
    CC accounts
  * Does not apply to tags or filters
  * CalDAV server must support extensible properties, e.g. Nextcloud or sabre/dav
* Target Android 15
* Return to previous view after searching
* Remove shadow from date picker sheet
* Fix updating list names and colors for Tasks.org and CalDAV accounts
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Czech - Fjuro
  * Dutch - @fvbommel
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @Colorful Rhino
  * Hebrew - Xo
  * Italian - @ppasserini
  * Turkish - @emintufan
  * Ukrainian - @IhorHordiichuk

### 14.7.4 (2025-07-12)

* @devn1x: Fix escaping quotes in iCalendar [#3645](https://github.com/tasks/tasks/pull/3645)
* Limit widget to 25 items on Android 16+
  * Android 16 nerfed widget performance 😢
* Fix bug when reconfiguring widget
* Fix default widget group sort order
* Update translations
  * Catalan - pitroig
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * German - @Kachelkaiser
  * Serbian - @vale-decem
  * Swedish - Nick Wick
  * Tamil - @TamilNeram

### 14.7.3 (2025-06-13)

* Fix dynamic color
* Fix Microsoft To Do sync failure
* Fix crash after deleting last list
* Fix notifications when 'Alarms & reminders' not allowed
* Update translations
  * Bulgarian - 109247019824
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * French - @FlorianLeChat
  * Hebrew - Xo
  * Japanese - M_Haruki
  * Persian - @theuser17
  * Portuguese - @nero-bratti
  * Romanian - @ygorigor
  * Russian - @yurtpage
  * Spanish - @orionn333
  * Swedish - @Nicklasfox
  * Turkish - @emintufan

### 14.7.2 (2025-05-23)

* Remove Microsoft Authentication Library from F-Droid builds [#3581](https://github.com/tasks/tasks/issues/3581)
* Remove contacts permission added by Microsoft Authentication Library
* Enable video attachments
* Fix wallpaper theme
* Fix handling multiple attachments
* Update translations
  * Arabic - abdelbasset jabrane
  * Bulgarian - 109247019824
  * Catalan - @Crashillo
  * Czech - Fjuro
  * Danish - @catsnote
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Turkish - @emintufan
  * Ukrainian - @IhorHordiichuk

### 14.7.1 (2025-05-04)

* Fix app closing itself automatically [#3366](https://github.com/tasks/tasks/issues/3366)
* Automatically set default list when connecting Microsoft To Do account
* Update translations
  * Arabic - abdelbasset jabrane, @kemo-1
  * Brazilian Portuguese - Jose Delvani
  * Chinese (Simplified) - Sketch6580
  * French - @FlorianLeChat
  * German - @Kachelkaiser

### 14.7 (2025-05-03)

* Add support for Microsoft To Do work & school accounts [#3267](https://github.com/tasks/tasks/issues/3267)
* Add ability to rename or delete local account
* Prompt to sign in or import backup on first launch
* @BeaterGhalio: Fix back button closing app after search [#3426](https://github.com/tasks/tasks/issues/3426)
* @codokie: Automirrored icons fix [#3499](https://github.com/tasks/tasks/pull/3499)
* @codokie: Fix ltr-rtl alignment for text input [#3489](https://github.com/tasks/tasks/pull/3489)
* Use system language picker on Android 33+
* Don't show 'due date' as a start date option for DAVx5, EteSync, DecSync CC [#1558](https://github.com/tasks/tasks/issues/1558)
* Prevent attempts to delete or rename Microsoft To Do default list
* Don't handle system 'Clear storage' button
* Update minimum Android version to 8
* Fix backup import dropping tags [#3556](https://github.com/tasks/tasks/issues/3556)
* Fix start date chip when grouping by start date [#3509](https://github.com/tasks/tasks/issues/3509)
* Update translations
  * Brazilian Portuguese - @sobeitnow0, dedakir923
  * Czech - Fjuro
  * Dutch - Jay Tromp
  * German - min7-i
  * Hebrew - Xo
  * Portuguese - @wm-pucrs
  * Russian - @hady-exc, Maksim_220 Кабанов
  * Slovak - @jose1711
  * Spanish - Nucl3arSnake, @diamondtipdr
  * Tamil - @TamilNeram

### 14.6.2 (2025-04-06)

* Show error indicators if 'When started' or 'When due' reminders are used
  without start or due times
* Fix delay when saving tasks
* Fix populating clock picker with initial value instead of 00:00
* Fix displaying selected calendar month
* Fix grouping by start date in descending order
* Update translations
  * Arabic - abdelbasset jabrane
  * Danish - @catsnote
  * Esperanto - Don Zouras
  * German - @Kachelkaiser
  * Hebrew - @elid34
  * Italian - @Fs00
  * Slovak - @jose1711
  * Turkish - @emintufan

### 14.6.1 (2025-03-30)

* Restore default sort mode for existing installs
* Fix grouping by due date descending
* Remove shadow from launcher icons

### 14.6 (2025-03-25)

* Add dynamic theme color - requires pro subscription
* Update translation
  * Brazilian Portuguese - dedakir923
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Estonian - Priit Jõerüüt
  * Italian - @ppasserini
  * Japanese - YuzuMikan
  * Swedish - @Ziron
  * Ukrainian - @IhorHordiichuk

### 14.5.4 (2025-03-24)

* Updated remaining date and time pickers to Material 3
  * App will remember if you change calendar or clock to text input
  * Text input now supported on start and due date pickers
  * Remove calendar and clock mode settings
* Open date picker to currently selected month
* Replaced upgrade pop-up with a banner [#1429](https://github.com/tasks/tasks/issues/1429)
* @hady-exc: Fix date picker time zone issues [#3248](https://github.com/tasks/tasks/pull/3248)
* Fix date time picker font scaling issues [#3437](https://github.com/tasks/tasks/issues/3437)
* Fix save task on keyboard done [#3288](https://github.com/tasks/tasks/issues/3288)
* Fix applying date time when dismissing date time pickers
* Fix 3 button navigation bar padding in landscape mode
* Fix out of memory errors in backup import/export
* Update translations
  * Brazilian Portuguese - dedakir923
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Dutch - @fvbommel
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - @franconian
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Romanian - @ygorigor
  * Tamil - @TamilNeram
  * Turkish - @emintufan

### 14.5.3 (2025-03-20)

* Updated date and time pickers to Material 3
* Remove 'Start of week' preference
  * This feature can't be supported with Material 3 calendars

### 14.5.2 (2025-03-15)

* Fix items hidden under menu search bar [#3406](https://github.com/tasks/tasks/issues/3406)
* Attempt to fix layout on some foldables
* Fix checking for tasks.org account [#3397](https://github.com/tasks/tasks/issues/3397)
* Slightly reduce donation nagging frequency [#3397](https://github.com/tasks/tasks/issues/3397)
* Update translations
  * Danish - Øjvind Fritjof Arnfred
  * Hungarian - Kaci
  * Malayalam - Clouds Liberty
  * Russian - @GREAT-DNG
  * Swedish - @bittin
  * Tamil - @TamilNeram

### 14.5.1 (2025-03-11)

* Fix performance issue when opening search
* Fix Microsoft To Do authentication crash
* Fix crash on task list screen
* Update translation
  * Brazilian Portuguese - dedakir923
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt
  * French - @FlorianLeChat
  * German - Colorful Rhino
  * Italian - @ppasserini
  * Kannada - Abilash S
  * Persian - @mamad-zahiri
  * Ukrainian - @IhorHordiichuk

### 14.5 (2025-03-04)

* Material 3 - work in progress
* Side navigation drawer
* Improve support for foldables
* Improve edge-to-edge support
* Remove options for top app bar and disabling collapsing app bar
  * Some features are being removed in order to make development easier for the
    upcoming desktop app. The features may return again in a future release.
* Save backup files and attachments to Nextcloud [#1289](https://github.com/tasks/tasks/issues/1289)
* Dismiss notification dialog when pressing cancel [#2116](https://github.com/tasks/tasks/issues/2116)
* Performance improvements
* Fix Microsoft To Do sync failure
* Fix missing list chips for subtasks in custom filters
* Fix for database timeouts
* Fix infinite subtask recursion
* Update translations
  * Belarusian - @fobo66
  * Estonian - Priit Jõerüüt
  * German - Colorful Rhino
  * Japanese - M_Haruki
  * Nahuatl - Benjamin Bruce
  * Slovak - @jose1711
  * Ukrainian - @IhorHordiichuk

### 14.4.8 (2025-02-04)

* Performance improvements
* Update translations
  * German - Colorful Rhino, @Kachelkaiser
  * Nepali - Sagun Khatri

### 14.4.7 (2025-02-01)

* Database improvements
* Update translations
  * Estonian - Priit Jõerüüt
  * German - @Kachelkaiser

### 14.4.6 (2025-01-29)

* Database performance improvements
* Additional debug logging
* Update translations
  * Danish - ERYpTION
  * Estonian - Priit Jõerüüt
  * German - @franconian, Colorful Rhino, @Kachelkaiser
  * Italian - @ppasserini
  * Korean - Sunjae Choi
  * Nepali - Sagun Khatri
  * Slovak - @jose1711
  * Swedish - Nick Wick

### 14.4.5 (2025-01-22)

* Performance improvements
* DAVx5 sync performance improvements
* Update translations
  * Bosnian - @hasak
  * Esperanto - Don Zouras
  * Estonian - Priit Jõerüüt, @dermezl
  * Italian - @ppasserini
  * Nepali - @sagunkhatri


### 14.4.4 (2025-01-19)

* Fix list pickers [#3269](https://github.com/tasks/tasks/issues/3269)

### 14.4.3 (2025-01-18)

* Preserve reminder recurrence when copying tasks
* Refresh task list after changing settings
* Fix missing chips for local lists
* Fix changes being lost when completing task from edit screen
* Update translations
  * German - @franconian
  * Turkish - @emintufan
  * Ukrainian - @IhorHordiichuk

### 14.4.2 (2025-01-16)

* Fix crash on missing account
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - Sketch6580
  * Croatian - @milotype
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * French - @FlorianLeChat, @CennoxX
  * German - @franconian
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Russian - @hady-exc
  * Slovak - @jose1711
  * Ukrainian - @IhorHordiichuk

### 14.4.1 (2025-01-11)

* Microsoft To Do support [#2011](https://github.com/tasks/tasks/issues/2011)
  * This feature is in early access, please report any bugs!
  * Enable under 'Advanced' settings
* Add configuration option for new lines in titles
* @TonSilver - Copy comments to clipboard with long press [#3212](https://github.com/tasks/tasks/pull/3212)
* @jheld - Attempt to fix F-Droid build with colorpicker fork [#2028](https://github.com/tasks/tasks/issues/2028)
* Subscription changes
  * Multiple Google Task accounts are now free to use
  * Tasker plugins are now free to use
* Fix crash on empty shortcut labels
* Fix missing settings button on Android 10 and below
* Update translations
  * Bulgarian - 109247019824
  * Chinese (Simplified) - 大王叫我来巡山, Sketch6580
  * Czech - @AtmosphericIgnition
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * French - @FlorianLeChat, @lfavole
  * German - @franconian, Colorful Rhino
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Slovak - @jose1711
  * Swedish - @Ziron, @bittin
  * Turkish - @emintufan

### 14.3.1 (2025-01-02)

* Fix edit screen disappearing on rotation
* Fix notification bundling issue
* Fix scrolling in custom filter settings
* Remove map theme and desaturation options
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Chinese (Simplified) - 大王叫我来巡山
  * Dutch - @fvbommel
  * French - @FlorianLeChat
  * German - @p-rogalski
  * Italian - @ppasserini
  * Korean - Sunjae Choi
  * Swedish - @bittin

### 14.3 (2024-12-24)

* "Add widget to home screen" shortcut in list settings
* "Add shortcut to home screen" shortcut in list settings
  * Shortcuts use list icon and color
* Fix long running sync indicators [#3045](https://github.com/tasks/tasks/issues/3045)
* @hady-exc: Migrate list setting screens to Compose [#3163](https://github.com/tasks/tasks/pull/3163)
* Update translations
  * Bosnian - @hasak
  * Bulgarian - @StoyanDimitrov
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * Esperanto - Don Zouras
  * Finnish - @pHamala, @Ricky-Tigg
  * German - @p-rogalski, @franconian, @Atalanttore
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Korean - Sunjae Choi
  * Spanish - gallegonovato
  * Swedish - Nick Wick

### 14.2.1 (2024-12-03)

* Fix save button when 'Back button saves task' is enabled [#3149](https://github.com/tasks/tasks/issues/3149)
* Fix customizing edit screen order screen

### 14.2 (2024-12-02)

* Updated edit screen task title
  * Show full title
  * Removed collapse on scroll
  * Removed floating action button
* Add separate alarms and reminders warning
* Capitalize tag picker text field
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Catalan - raulmagdalena
  * Chinese (Simplified) - 大王叫我来巡山
  * Dutch - @fvbommel
  * French - @FlorianLeChat
  * Italian - @ppasserini
  * Spanish - gallegonovato
  * Ukrainian - @nathalier

### 14.1.1 (2024-11-26)

* Show warning when quiet hours are in effect
* Fix escape character in some localizations [#3046](https://github.com/tasks/tasks/issues/3046)
* Fix comment delete button color [#3102](https://github.com/tasks/tasks/issues/3102)
* Update translations
  * Bosnian - @hasak
  * Bulgarian - @StoyanDimitrov
  * Catalan - raulmagdalena
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * French - @FlorianLeChat
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Polish - @rom4nik
  * Spanish - gallegonovato
  * Swedish - Nick Wick

### 14.1 (2024-11-20)

* Add 'Help & Feedback > Send application logs'
* Delete snoozed reminders when completing tasks
* Fix duplicated tasks when using 'Share' [#2404](https://github.com/tasks/tasks/issues/2404)
* Don't show sync indicator on startup when sync is not used
* Update translations
  * Bosnian - @hasak
  * Brazilian Portuguese - kowih83264
  * Croatian - @milotype
  * German - min7-i

### 14.0.1 (2024-11-10)

* Fix widget crash
* Fix EteSync sync failure [#3092](https://github.com/tasks/tasks/issues/3092)
* Minor Wear OS improvements
* Update translations
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Kannada - @historicattle
  * Marathi - @historicattle
  * Spanish - gallegonovato
  * Swedish - @bittin

### 14.0 (2024-11-05)

* Wear OS support (Google Play only)
* Move drawer items to top unless searching
* Fix drawer item layout issues
* Update translations
  * Brazilian Portuguese - Nicolas Suzuki, pogoyar888
  * Bulgarian - @StoyanDimitrov
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - hugoalh
  * Dutch - Luna, @fvbommel
  * French - @FlorianLeChat
  * German - @p-rogalski, @franconian
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Spanish - gallegonovato
  * Swedish - @bittin
  * Turkish - @oersen
  * Ukrainian - @IhorHordiichuk

### 13.11.2 (2024-09-29)

* Target Android 14
* Fix crash in location picker [#2990](https://github.com/tasks/tasks/issues/2990)
* Fix SQLite crash [#3045](https://github.com/tasks/tasks/issues/3045)
* Update translations
  * Arabic - @sanabel-al-firdaws
  * Belarusian - @katalim
  * Brazilian Portuguese - Jose Delvani
  * Catalan - raulmagdalena, @truita
  * Chinese (Traditional) - @abc0922001
  * Croatian - @milotype
  * Czech - atmosphericignition
  * Danish - Tntdruid, Luna
  * Dutch - @VIMVa
  * Esperanto - Don Zouras
  * Estonian - @dermezl
  * German - @Atalanttore, @tct123
  * Italian - @ppasserini
  * Norwegian Bokmål - @RonnyAL
  * Swedish - @JonatanWick, @bittin

### 13.11.1 (2024-07-15)

* Fix crash when collapsing list picker sections
* Fix crash in database migration
* Enabled Managed DAVx5
* Update translations
  * Bulgarian - @StoyanDimitrov

### 13.11 (2024-07-14)

* New icon picker with over 2,100 icons! (pro feature)
* Fix Todo Agenda Widget integration [todoagenda/#145](https://github.com/andstatus/todoagenda/issues/145)
* Fix menu search bar on Android 10 and below [#2966](https://github.com/tasks/tasks/issues/2966)
* Update translations
  * Brazilian Portuguese - Jose Delvani
  * Bulgarian - @StoyanDimitrov
  * Catalan - @Seveorr, @jtorrensamer
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - hugoalh
  * French - @FlorianLeChat
  * Spanish - gallegonovato
  * Turkish - @oersen
  * Ukrainian - @IhorHordiichuk

### 13.10 (2024-07-05)

* Add search bar to drawer
* Add search bar to list picker
* Move 'Manage drawer' to ⚙️ > Navigation drawer
* Android 13+ users must grant additional reminder permissions
* Fix completing task multiple times from notification
* Fix deleting new subtasks from edit screen
* ~~Enable Managed DAVx5~~
* Update translations
  * Arabic - @islam2hamy
  * Brazilian Portuguese - Jose Delvani
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - hugoalh
  * Croatian - @milotype
  * Finnish - Rami Lehtinen, @CSharpest
  * German - min7-i
  * Spanish - gallegonovato
  * Turkish - @oersen

### 13.9.9 (2024-05-30)

* Fix import backup crashes
* Fix showing completed subtasks in edit screen

### 13.9.7 (2024-05-23)

* Add default reminders when adding start/due dates to existing tasks [#1846](https://github.com/tasks/tasks/issues/1846)
* Fix import backup crash

### 13.9.6 (2024-05-18)

* Fix widget crash [#2873](https://github.com/tasks/tasks/issues/2873)
* Fix recurrence unable to finish [#2874](https://github.com/tasks/tasks/issues/2874)
* Fix edit screen being cleared when reopening app [#2857](https://github.com/tasks/tasks/issues/2857)
* Fix performance regressions
* Simplified internal alarm scheduling logic
* Update translations
  * Arabic - @islam2hamy
  * Bulgarian - @StoyanDimitrov

### 13.9 (2024-05-01)

* @elmuffo: Add swipe-to-snooze [#2839](https://github.com/tasks/tasks/pull/2839)
* @IlyaBizyaev: Add option to use quick tile without unlocking device [#2847](https://github.com/tasks/tasks/pull/2847)
* @liz-desartiges: Add support for Z Flip 5 cover screen [#2843](https://github.com/tasks/tasks/pull/2843)
* @purushyb: Fix drawer not updating after editing items [#2855](https://github.com/tasks/tasks/pull/2855)
* @hady-exc: Migrate tag picker screen to Compose [#2849](https://github.com/tasks/tasks/pull/2849)
* @yurtpage: Add Russian app store description [#2848](https://github.com/tasks/tasks/pull/2848)
* Fix duplicate notifications [#2835](https://github.com/tasks/tasks/issues/2835)
* Fix adding '(Completed)' to calendar entries [#2832](https://github.com/tasks/tasks/issues/2832)
* Fix hiding empty items from drawer [#2831](https://github.com/tasks/tasks/issues/2831)
* Exclude old snoozed tasks from snoozed task filter
* Update translations
  * Brazilian Portuguese - @mayhmemo, @gorgonun
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * Esperanto - Don Zouras
  * French - Lionel HANNEQUIN
  * German - sorifukobexomajepasiricupuva33, min7-i
  * Portuguese - @fparri, @laralem
  * Spanish - gallegonovato
  * Swedish - @JonatanWick
  * Turkish - @emintufan, @oersen

### 13.8.1 (2024-03-24)

* Fix copy causing duplicate Google Tasks
* Fix navigation drawer crash
* Fix backup import dropping tasks

### 13.8 (2024-03-22)

* Dynamic widget theme (name-your-price subscription required)
* Replace 'until' with 'ends on' for repeating tasks [#2797](https://github.com/tasks/tasks/pull/2797) - @akwala
* Fix loading selected list on startup [#2777](https://github.com/tasks/tasks/issues/2777)
* Fix repeating tasks ending one day early
* Fix repeating task crash
* Fix backup import crash
* Fix Astrid manual ordering crash in widget
* Update translations
  * Brazilian Portuguese - @mayhmemo
  * Bulgarian - @StoyanDimitrov
  * Catalan - @ferranpujolcamins
  * Chinese (Simplified) - 大王叫我来巡山
  * Croatian - @milotype
  * Czech - Odweta
  * German - @macpac59
  * Italian - @ppasserini
  * Spanish - gallegonovato
  * Swedish - @bittin
  * Ukrainian - @IhorHordiichuk
  * Vietnamese - @ngocanhtve

### 13.7 (2024-02-07)

* Fix returning to previous filter after search [#2700](https://github.com/tasks/tasks/pull/2700)
* Fix wearable notifications on Android 14+
* Fix issue causing repeating tasks to not repeat
* Fix dragging a task into a subtask in another list
* Rewrote navigation drawer in Jetpack Compose
* Internal changes to navigation
* Enable multi-select when adding attachments
* Show count of tasks to be deleted when clearing completed
* Include hidden subtasks when clearing completed [#2724](https://github.com/tasks/tasks/issues/2724)
* Don't show hidden or completed tasks in snoozed filter
* Remove markdown from repeating task snackbar
* Update translations
  * Azerbaijani - Shaban Mamedov
  * Bulgarian - @StoyanDimitrov
  * Catalan - raulmagdalena
  * Chinese (Simplified) - 大王叫我来巡山
  * Chinese (Traditional) - @abc0922001
  * Croatian - @milotype
  * Dutch - @mm4c
  * Esperanto - Don Zouras
  * Finnish - @millerii
  * French - J. Lavoie
  * German - @CennoxX
  * Hebrew - @elig0n
  * Interlingua - @softinterlingua
  * Odia - @SubhamJena
  * Persian - @Monirzadeh
  * Spanish - gallegonovato
  * Swedish - @bittin
  * Turkish - @oersen
  * Ukrainian - Сергій
  * Vietnamese - @ngocanhtve

### 13.6.3 (2023-11-25)

* Revert "Preserve modification times on initial sync" [#2460](https://github.com/tasks/tasks/issues/2640)
* Fix unnecessary DecSync work

### 13.6.2 (2023-10-30)

* Fix updating modification timestamp on edits

### 13.6.1 (2023-10-27)

* Push pending changes when app is backgrounded
* Don't require internet connection for DAVx5/EteSync/DecSync sync
* Don't perform background sync for DAVx5/EteSync/DecSync
  * Background sync is performed by the sync app
* Preserve modification times on initial sync [#2496](https://github.com/tasks/tasks/issues/2496)
* Replace deprecated method call [#2547](https://github.com/tasks/tasks/pull/2547) - @kmj-99
* Improve task list scrolling performance
* Fix hourly recurrence bug
* Update translations
  * Chinese (Simplified) - Eric
  * Croatian - @milotype
  * Czech - @ceskyDJ
  * Finnish - @millerii
  * French - Lionel HANNEQUIN, Bruno Duyé
  * Japanese - Kazushi Hayama
  * Portuguese - @loucurapt
  * Romanian - @ygorigor
  * Swedish - @bittin

### 13.6 (2023-10-07)

* Change priority with multi-select [#2257](https://github.com/tasks/tasks/pull/2452) - @vulewuxe86
* Automatically select newly copied tasks [#2246](https://github.com/tasks/tasks/pull/2446) - @vulewuxe86
* Reduce minimum size for widgets [#2436](https://github.com/tasks/tasks/pull/2436) - @histefanhere
* Replace deprecated method call [#2526](https://github.com/tasks/tasks/pull/2526) - @kmj-99
* Improve handling text shared to Tasks [#2485](https://github.com/tasks/tasks/issues/2485)
* Use notification audio stream for completion sound
* Notification preference 'More settings' opens channel settings directly
* Respect 'New tasks on top' preference when creating subtasks
* Automatically add due dates for recurring tasks
* Fix crash on startup
* Update translations
  * Brazilian Portuguese - @gorgonun
  * Bulgarian - @StoyanDimitrov, @salif
  * Catalan - Joan Montané
  * Chinese (Simplified) - Poesty Li
  * Chinese (Traditional) - @abc0922001
  * Dutch - @fvbommel
  * French - @FlorianLeChat
  * German - @qwerty287, deep map, @franconian
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Japanese - Kazushi Hayama, Naga
  * Spanish - @FlorianLeChat
  * Swedish - @Anaemix, @bittin
  * Turkish - @emintufan, @oersen
  * Ukrainian - @IhorHordiichuk

### 13.5.1 (2023-08-02)

* Fix crash when importing Google Tasks from a backup file
* Added Burmese translations - @htetoh
* Update translations
  * Chinese (Simplified) - Poesty Li
  * Croatian - @milotype
  * Japanese - Kazushi Hayama
  * Polish - @alex-ter
  * Russian - @alex-ter
  * Ukrainian - @IhorHordiichuk
  * Vietnamese - @unbiaseduser

### 13.5 (2023-07-28)

* New custom recurrence picker
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Czech - @ceskyDJ
  * Dutch - @fvbommel
  * French - @FlorianLeChat
  * Italian - @ppasserini
  * Spanish - @FlorianLeChat

### 13.4 - (2023-07-16)

* Sorting improvements
  * Add subtask sort configuration
  * Update sort menu button design
* Don't show subtasks of hidden tasks in 'My Tasks'
* Fix Google Tasks sync issue
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Catalan - @and4po, Eudald Puy Polls
  * Croatian - @milotype
  * Dutch - @fvbommel
  * German - @schneidr
  * Hungarian - Kaci
  * Japanese - Naga
  * Korean - Sunjae Choi
  * Portuguese - @laralem
  * Swedish - @bittin

### 13.3.2 - (2023-06-02)

* Sorting improvements
  * Configure sort grouping
  * Configure sorting within sort group
  * Configure completed task sorting
* Fix Google Task list chips showing on widget
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Catalan - @and4po
  * Chinese (Simplified) - Poesty Li
  * Croatian - @milotype
  * Dutch - @fvbommel
  * French - @FlorianLeChat
  * German - @qwerty287, @franconian
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Spanish - @FlorianLeChat
  * Ukrainian - @IhorHordiichuk

### 13.2.4 - (2023-05-24)
* Add 'By list' sort mode [#1265](https://github.com/tasks/tasks/issues/1265)
* Save task when pressing done [#2125](https://github.com/tasks/tasks/pull/2125)
* Use ISO 8601 date formatting for backup filenames [#1550](https://github.com/tasks/tasks/pull/1550)
* Fix filter sorting bug [#1561](https://github.com/tasks/tasks/issues/1561)
* Fix manual sorting crash [#2141](https://github.com/tasks/tasks/issues/2141)
* Fix manual sorting bug [#2101](https://github.com/tasks/tasks/issues/2101)
* Fix multiple accounts on same server [#2301](https://github.com/tasks/tasks/issues/2301)
* Don't set `COUNT=0` on recurrence rules [#2158](https://github.com/tasks/tasks/issues/2158)
* Improve task list performance [#2062](https://github.com/tasks/tasks/issues/2062)
* Attempt to hide inactive widgets in settings [#2145](https://github.com/tasks/tasks/issues/2145)
* Disable persistent reminders on Android 14+
  * Android 14+ no longer supports persistent reminders 😢
* Fix notifications on Android 14
* Fix crash when missing exact alarm permissions
* Update logic for adding default reminders during sync
  * Don't add reminders on initial sync
  * Don't add reminders if other client supports reminder sync
* Internal database changes
  * You will need to reconfigure any widgets that were set to display a Google
    Task list or filter. Sorry for the interruption!
* Add Odia translations - @SubhamJena
* Update translations
  * Brazilian Portuguese - @lnux-usr
  * Bulgarian - @StoyanDimitrov
  * Catalan - @and4po
  * Chinese (Simplified) - Poesty Li
  * Chinese (Traditional) - Chih-Hsuan Yen
  * Croatian - @milotype
  * Dutch - @fvbommel
  * Esperanto - Don Zouras
  * Finnish - @millerii
  * French - @FlorianLeChat
  * Italian - @ppasserini
  * Japanese - @kisaragi-hiu, Naga
  * Korean - Sunjae Choi, @o20n3
  * Romanian - @simonaiacob
  * Russian - @AHOHNMYC
  * Spanish - @FlorianLeChat
  * Turkish - @ersen0
  * Ukrainian - @IhorHordiichuk

### 13.1.2 (2023-02-02)

* Add default reminders to incoming iCalendar tasks [#1984](https://github.com/tasks/tasks/issues/1984)
* Sync when brought to the foreground [#2096](https://github.com/tasks/tasks/issues/2096)
* Update translations
  * Arabic - haidarah esmander
  * Czech - @SlavekB
  * Danish - Tntdruid
  * Esperanto - Don Zouras, @J053Fabi0
  * Finnish - @millerii
  * German - @franconian
  * Italian - @ppasserini
  * Japanese - Kazushi Hayama
  * Korean - @o20n3
  * Polish - @gnu-ewm
  * Vietnamese - @unbiaseduser

### 13.1.1 (2022-12-06)

* Fix crash when opening notification settings
* Fix IAP errors in some locales
* Update translations
  * Italian - @ppasserini
  * Japanese - Kazushi Hayama

### 13.1.0 (2022-11-30)

* Support for DAVx5 and CalDAV read-only lists [#931](https://github.com/tasks/tasks/issues/931)
* Use default Android network security configuration
* Update translations
  * Bulgarian - @StoyanDimitrov
  * Chinese (Simplified) - Eric
  * Croatian - @milotype
  * Dutch - @fvbommel
  * Finnish - @millerii
  * French - @FlorianLeChat
  * German - @helloworldtest123
  * Hungarian - Kaci
  * Italian - @ppasserini
  * Lithuanian - @70h
  * Russian - Nikita Epifanov
  * Spanish - @FlorianLeChat
  * Turkish - @ersen0
  * Ukrainian - @IhorHordiichuk

### 13.0.2 (2022-11-22)

* Fix persistent notifications on Android 13
* Fix Samsung crash on too many reminders (DAVx5, EteSync, DecSync CC)
* Fix crash on too many tasks for Astrid Manual Sorting
* Fix RTL text in task edit customization screen
* Fix priority button order

### 13.0.1 (2022-10-20)

* 🚨 Major internal changes to task edit screen. Please report any bugs! 🚨
* Show thumbnails for attachments
* Tap on existing alarms to replace them
* Add task info row to edit screen [#1839](https://github.com/tasks/tasks/pull/1839)
* Add option to disable reminders for all-day tasks [#2003](https://github.com/tasks/tasks/pull/2003)
* Updated chip style
* Show geofence circle in place settings
* Fix removing preferences [#1981](https://github.com/tasks/tasks/pull/1981)
* Set user-agent on HTTP requests [#1978](https://github.com/tasks/tasks/issues/1978)
* Preserve HTTP session cookies [#1978](https://github.com/tasks/tasks/issues/1978)
* Sort selected tags at top of tag picker
* Android 13 support
  * Runtime notification permissions
  * Language preference
* Improvements to copying tasks
  * Don't forget parent when copying tasks [#1964](https://github.com/tasks/tasks/pull/1964)
  * Copy attachments when duplicating tasks [#812](https://github.com/tasks/tasks/issues/812)
  * Fix duplicating subtasks
* Fix some missing reminders
  * Incoming Google Tasks
  * Tasker tasks [#1937](https://github.com/tasks/tasks/issues/1937)
  * New subtasks [#1914](https://github.com/tasks/tasks/issues/1914)
* Fix Google Task creation time
* Fix EteSync stops synchronizing [#1893](https://github.com/tasks/tasks/issues/1893)
* Don't overwrite coordinates when synchronizing locations [#1667](https://github.com/tasks/tasks/issues/1667)
* Update translations
  * Asturian - @enolp
  * Basque - Sergio Varela
  * Bulgarian - @StoyanDimitrov
  * Chinese (Simplified) - Eric
  * Croatian - @milotype
  * Czech - Shimon
  * Dutch - @fvbommel
  * French - @FlorianLeChat, J. Lavoie
  * German - @qwerty287
  * Italian - @ppasserini
  * Norwegian Bokmål - @comradekingu
  * Persian - @latelateprogrammer
  * Polish - @ebogucka
  * Portuguese - @laralem
  * Romanian - @simonaiacob
  * Russian - @Allineer, Nikita Epifanov
  * Sinhala - @Dilshan-H
  * Spanish - @FlorianLeChat
  * Turkish - @ersen0
  * Ukrainian - @IhorHordiichuk, @artemmolotov
  * Vietnamese - @unbiaseduser

[Older releases](https://github.com/tasks/tasks/blob/main/V10_12_CHANGELOG.md)
