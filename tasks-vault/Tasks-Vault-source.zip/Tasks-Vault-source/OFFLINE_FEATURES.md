# Tasks Vault: offline customization edition

This GPLv3 fork builds the Compose Android app as `com.macdarenz.tasks.vault`.
The APK includes the following local customization without purchase or account setup:

- All 41 preset color choices and a custom RGB/hex editor for app, list, and tag colors.
- Bundled list/tag icons with local search and persistent selections.
- Light, black, dark, wallpaper, scheduled day/night, and system theme modes.
- Scheduled day/night uses local time: light from 07:00 until 19:00; dark otherwise.
- Android 12+ device color palettes, with manual-color fallback on earlier Android versions.
- Twenty launcher icon colors, with a reset to blue. Android persists the selected launcher component.
- The existing encrypted, device-only private Vault, opened by tapping the task-list logo five times.

Task/list/tag storage stays local. The Android manifest removes Internet permission and excludes
automatic cloud backup and device transfer. Sync providers, account sign-in, sharing, desktop
linking, pricing, upgrade, purchase restoration, and cloud migration have no active UI in this build.
Local customization access does not claim a Tasks.org subscription or grant server access.
Cached lists from older account configurations can be edited locally without contacting a server;
new lists belong to a local account.

The Vault retains Android Keystore encryption and separate no-backup storage, screenshot protection,
background/manual/timeout locking, PIN attempt throttling, and clipboard cleanup. Storage failures
are shown in the UI; concurrent writes and stale callbacks after locking are rejected.

## Build

Use a full JDK 21 and an Android SDK with the configured platform/build tools:

```sh
./gradlew :composeApp:assembleFdroidRelease
```

The APK is written to `composeApp/build/outputs/apk/fdroid/release/` and requires Android 8.0+.
The provided APK uses a local test signing key; private signing material is not part of this source.
Build tools may download dependencies; the resulting Android application has no Internet permission.
The separate legacy `:app` target is upstream code and is not the APK delivered by this fork.

## Verification scope

Focused tests cover custom color parsing, malformed/alpha color rejection, local list/tag customization
persistence and rendering, sharing suppression for cached remote metadata, and separation of local
feature access from server subscriptions. JVM test bytecode targets Java 25, so those tests need a
Java 25 runtime. Android compilation targets Java 17 bytecode.

This change does not port missing baseline Android Compose adapters. Notification delivery, widgets,
manual backup/import, custom-filter editing, and calendar/location integrations remain porting gaps
in this target. Cloud/server features require a separate connected build.
